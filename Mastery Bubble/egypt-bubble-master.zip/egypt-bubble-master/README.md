# Egypt Bubble

Bubble Puzzle game with basic logic by monogame.

## Installation

***Windows***:

> Check installer windows version (Win10 DX support) in __releases__ page.

## Screen Shot

![Menu Screen](Screenshot/01.png)

![GamePlay Screen](Screenshot/02.png)

## Release History
* 1.0.0
    * First release game version.
    * Have little bugs.
